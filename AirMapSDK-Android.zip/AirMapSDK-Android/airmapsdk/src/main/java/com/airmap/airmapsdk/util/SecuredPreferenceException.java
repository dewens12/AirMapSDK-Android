package com.airmap.airmapsdk.util;

public class SecuredPreferenceException extends Exception {

    public SecuredPreferenceException(String message) {
        super(message);
    }
}