package com.airmap.airmapsdk.ui.adapters;

public interface EmptyableAdapter {
    String getEmptyText();
}
