package com.airmap.airmapsdk.networking.callbacks;

public interface LoginListener {
    void shouldAuthenticate();
}
