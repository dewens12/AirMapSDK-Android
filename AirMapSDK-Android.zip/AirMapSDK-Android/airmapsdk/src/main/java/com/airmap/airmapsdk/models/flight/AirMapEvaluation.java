package com.airmap.airmapsdk.models.flight;

public class AirMapEvaluation extends AirMapFlightBriefing {
}
