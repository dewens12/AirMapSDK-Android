"use strict"
var buffer = require('turf-buffer')
var linestring = require('turf-linestring')
var bboxpolygon = require('turf-bbox')
var erase = require('turf-erase')

global.buffer = buffer
global.linestring = linestring
global.bboxpolygon = bboxpolygon
global.erase = erase
